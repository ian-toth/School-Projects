This is an example project that I made in highschool (2018) for a blackjack game. This was one of the first "larger" projects I made,
the focus for me here was mainly learning how to use functions that were not all located in the same class, but this should give some 
nice insight into my beginnings.